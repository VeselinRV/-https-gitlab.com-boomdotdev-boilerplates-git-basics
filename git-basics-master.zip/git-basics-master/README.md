# ⚙ Git Basics Boilerplate 
This project is used as a boilerplate for tasks in the "Git Basics" course in Booost

🟡🟡🟡